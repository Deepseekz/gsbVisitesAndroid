<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class OrmsController extends AppController {

    public function index() {
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table

        $query = $etudiants->find('all'); //entities

        $this->set('query', $query);
        $this->render('debug');
    }

    public function nomPrenom() {
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table

        $query = $etudiants->find('all'); //entities
        $query = $query
                ->select(['nom', 'prenom']);

        $this->set('query', $query);
        $this->render('debug');
    }

    public function sisr2019() {
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table

        $query = $etudiants->find('all'); //entities
        $query = $query
                ->where(['specialite' => 'SISR', 'promo' => 2019]);

        $this->set('query', $query);
        $this->render('debug');
    }

    public function EtudiantSerieBac() {
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table

        $etudiants->belongsTo('bacs'); //association


        $query = $etudiants->find('all'); //entities
        $query = $query
                ->contain('bacs')
                ->select(['nom', 'prenom', 'bacs.serie']);

        $this->set('query', $query);
    }

    public function EtudiantCompetences() {
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table
        $etudiants->belongsToMany('Competences'); //association

        $query = $etudiants->find('all') //entities
                ->contain(['Competences']);

        $this->set('query', $query);
    }

    public function NombreEtudiantSerieBac() {
        $etudiants = TableRegistry::getTableLocator()->get('Bacs'); //table
        $etudiants->hasMany('Etudiants'); //association

        $query = $etudiants->find('all'); //entities
        $query = $query->matching('Etudiants')
                ->select(['serie', 'nbEtudiants' => $query->func()->count('*')])
                ->group('serie');

        $this->set('query', $query);
        $this->render('debug');
    }
    
    public function Etudiants($filtre="") {
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table

        $query = $etudiants->find('all'); //entities
        $query = $query
                ->select(['nom', 'prenom'])
                ->where(['nom LIKE' => $filtre.'%']);

        $this->set('query', $query);
    }
    
    public function Competences() {
        $etudiants = TableRegistry::getTableLocator()->get('Competences'); //table

        $query = $etudiants->find('all'); //entities
        $query = $query
                ->select(['code', 'libelle']);

        $this->set('query', $query);
    }
    
    public function Bacs() {
        $etudiants = TableRegistry::getTableLocator()->get('Bacs'); //table
        $etudiants->hasMany('Etudiants'); //association

        $query = $etudiants->find('all'); //entities
        $query = $query->matching('Etudiants')
                ->select(['serie', 'nbEtudiants' => $query->func()->count('*')])
                ->group('serie');

        $this->set('query', $query);
    }
    
    public function EtudiantTableauSynthese() {
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table
        $etudiants->belongsToMany('Competences');
        
        $query = $etudiants->find('all'); //entities
        $query = $query
                ->select(['id','nom', 'prenom'])
                ->contain(['Competences']);

        $this->set('query', $query);
    }

}
