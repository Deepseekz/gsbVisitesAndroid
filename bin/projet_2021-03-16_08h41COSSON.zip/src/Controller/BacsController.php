<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Bacs Controller
 *
 * @property \App\Model\Table\BacsTable $Bacs
 *
 * @method \App\Model\Entity\Bac[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class BacsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $bacs = $this->paginate($this->Bacs);

        $this->set(compact('bacs'));
    }

    /**
     * View method
     *
     * @param string|null $id Bac id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $bac = $this->Bacs->get($id, [
            'contain' => ['Etudiants']
        ]);

        $this->set('bac', $bac);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $bac = $this->Bacs->newEntity();
        if ($this->request->is('post')) {
            $bac = $this->Bacs->patchEntity($bac, $this->request->getData());
            if ($this->Bacs->save($bac)) {
                $this->Flash->success(__('The bac has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The bac could not be saved. Please, try again.'));
        }
        $this->set(compact('bac'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Bac id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $bac = $this->Bacs->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $bac = $this->Bacs->patchEntity($bac, $this->request->getData());
            if ($this->Bacs->save($bac)) {
                $this->Flash->success(__('The bac has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The bac could not be saved. Please, try again.'));
        }
        $this->set(compact('bac'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Bac id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $bac = $this->Bacs->get($id);
        if ($this->Bacs->delete($bac)) {
            $this->Flash->success(__('The bac has been deleted.'));
        } else {
            $this->Flash->error(__('The bac could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
